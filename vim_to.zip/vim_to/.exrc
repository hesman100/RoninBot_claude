"==== some function for VIM ====
"name	Setmouse
"Function	Enable/Disable mouse
:function! Setmouse()
:if &mouse =~ "a"
: set mouse =i
:echo "mouse=i"
:else
: set mouse =a
:echo "mouse=a"
:endif
:endfunction
map sm :call Setmouse()<CR>
"==========================================
:function SetCursorLine()
:if g:mcl ==0
: set cursorline cursorcolumn
: let g:mcl=1
:else
: set cursorline!
: set cursorcolumn!
:let g:mcl=0
:endif
:endfunction
"----
let g:mcl=0
map cl :call SetCursorLine()<CR>
"=========================================
"name	set wrap
"Function	Enable/Disable Wrap
:function! Setwrap()
:if (&wrap == 0)
: set wrap
:echo "wrap"
:else
: set nowrap
:echo "nowrap"
:endif
:endfunction
map wr :call Setwrap()<CR>

"==========================================
:function Set_color_black()
:if g:i_color ==0
: set t_Co=0 
: let g:i_color=1
:else
: set t_Co=256 
:let g:i_color=0
:endif
:endfunction
"----
let g:i_color=0
map sc :call Set_color_black()<CR>


