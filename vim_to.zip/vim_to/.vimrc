
"execute pathogen#infect()
syntax on
"filetype plugin indent on
  

set hlsearch
set incsearch

set wrap
set ruler

set backspace=indent,eol,start
"set mouse=a
set guioptions+=b

set autoindent
"" ---- nerd tree setting ------
"autocmd VimEnter * NERDTree
map <C-n> :NERDTreeToggle<CR>
" map use use tab : 1, : goto next tab
map     1,       1gt
map     2,       2gt
map     3,       3gt
map    <C-Up>    :tabnext<CR>
map    <C-Down>  :tabprevious<CR>
"" ------------------------

"" --- python setting ----
" autocmd BufRead,BufNewFile *.kv setfiletype python
" The <Leader> key is mapped to \ by default.
" execute pathogen#infect()
"filetype off
" call pathogen#runtime_append_all_bundles()
" call pathogen#helptags()
set nocompatible              " required
filetype off                  " required
set foldmethod=indent
set foldlevel=99
" Enable folding with the spacebar
nnoremap <space> za  

" set the runtime path to include Vundle and initialize
" set rtp+=~/.vim/bundle/Vundle.vim
" call vundle#begin()

" alternatively, pass a path where Vundle should install plugins
"call vundle#begin('~/some/path/here')

" let Vundle manage Vundle, required
" Plugin 'gmarik/Vundle.vim'
" Plugin 'tmhedberg/SimpylFold'
" Plugin 'vim-scripts/indentpython.vim'
" Plugin 'vim-syntastic/syntastic'
" Plugin 'Lokaltog/powerline', {'rtp': 'powerline/bindings/vim/'}
" Plugin 'nvie/vim-flake8'
" Plugin 'kien/ctrlp.vim'
" Plugin 'vim-airline/vim-airline'
" Plugin 'vim-airline/vim-airline-themes'

" add all your plugins here (note older versions of Vundle
" used Bundle instead of Plugin)
"Bundle 'Valloric/YouCompleteMe'

" ...

" All of your Plugins must be added before the following line
"call vundle#end()            " required
filetype plugin indent on    " required
"
set tabstop=2
" autocmd FileType python set autoindent|set smartindent
" " 4 space tabs
"
" autocmd FileType python set tabstop=2|set shiftwidth=2|set expandtab|set softtabstop=2
"
" au BufNewFile,BufRead *.py 
"   set tabstop=4 
"   set softtabstop=4 
"   set shiftwidth=4 
"   set textwidth=79
"   set expandtab  
"   set autoindent 
"   set fileformat=unix 

"au BufRead,BufNewFile *.py,*.pyw,*.c,*.h match BadWhitespace /\s\+$/

" let python_highlight_all=1
" let g:SimpylFold_docstring_preview=1
" let g:ycm_autoclose_preview_window_after_completion=1
" map <leader>g  :YcmCompleter GoToDefinitionElseDeclaration<CR>
syntax on

"" --- end python
let g:airline#extensions#tabline#enabled = 1

" don't show the toolbar in the GUI (only the menu)
"set guioptions-=T

" don't show tear-off menus
"set guioptions-=t
set nocompatible
set showcmd
set history=100
"set autoindent
set tabstop=2
set expandtab
set nowrap
set ffs=unix,dos
"set statusline ='%t%c'
syntax enable
:filetype plugin on
":filetype on
autocmd BufRead,BufNewFile *.v,*.vh setfiletype verilog
autocmd BufRead,BufNewFile *.v,*.vh set expandtab tabstop=2 softtabstop=2 shiftwidth=2
autocmd BufRead,BufNewFile *.sv,*.svi,*.sva set filetype=verilog_systemverilog
autocmd BufRead,BufNewFile *.sv,*.svi,*.sva set expandtab tabstop=2 softtabstop=2 shiftwidth=2

autocmd BufRead,BufNewFile *.hs,*.lhs set filetype=haskell
autocmd BufRead *.hs,*.lhs    map <F5> <Esc><Home>i-- <Esc>
autocmd BufRead,BufNewFile *.hs,*.lhs set   tabstop=2|set shiftwidth=2|set expandtab|set softtabstop=2
autocmd FileType haskell                set autoindent|set smartindent

""ktram add ;
"commant in shell =====================
map <F8> <Esc>i<%=  %><Esc>hhhi
map <F9> <Esc><Home>i<!--k  <End> --> <Esc>
map <F12> i<Home>  <Esc>
map cv <Esc>$a<tab>//k_<Esc>
map cp <Esc>$a<tab>#k_<Esc>
"upper-lower and vise versa====
map <F3> bve~<Esc>
"map a    i
" map <F4> <Esc><End>a  //k_ <C-R>=strftime("%d-%b-%Y %H:%M")<CR> <Esc>
map <F5> <Esc><Home>i#_ <Esc>
autocmd BufRead *.sv,*.svi,*.v    map <F5> <Esc><Home>i//_ <Esc>
"autocmd BufRead *.csh,*.pl,*.bat  map <F5> <Esc><Home>i#_ <Esc>

"autocmd BufRead *.csh,*.pl,*.bat  map <F4> <Esc><End>a  #_ <C-R>=strftime("%d-%b-%Y %H:%M")<CR> <Esc>
map <F4> <Esc><End>a  #_ <C-R>=strftime("%d-%b-%Y %H:%M")<CR> <Esc>
autocmd BufRead *.sv,*.svi,*.v    map <F4> <Esc><End>a  //_ <C-R>=strftime("%d-%b-%Y %H:%M")<CR> <Esc>

"plugin 'tomlion/vim-solidity'
"plug 'tomlion/vim-solidity'


nmap \ %

inoremap <C-\> <C-N>

autocmd FileType perl set autoindent|set smartindent
" 4 space tabs
autocmd FileType perl set tabstop=2|set shiftwidth=2|set expandtab|set softtabstop=2
" show matching brackets
autocmd FileType perl set showmatch
" show line numbers
"autocmd FileType perl set number

" map key for tab in vim =======
map tb    <Esc>:tabedit <C-D>
map <C-F>  <Esc>:tabp<cr>
map <C-B>  <Esc>:tabn<cr>
map dc   <Esc><Home>3x<Esc>
map un   <Esc>:set noautoindent nosmartindent<cr>
map nu   <Esc>:set number<cr>
"" map :Fw to fw : folder search -> hiden not match line # https://github.com/embear/vim-foldsearch
map fw   <Esc>:Fw<cr>

" Uncomment the following to have Vim jump to the last position when  reopening a file
if has("autocmd")
        au BufReadPost * if line("'\"") > 1 && line("'\"") <= line("$") | exe "normal! g'\"" | endif 
endif


:source ~/.exrc

" disable auto add new line in vim :
"set textwidth=0 wrapmargin=0
set tw=0

set          t_Co=256
setlocal cm=blowfish2
" japanese encode//
set enc=utf-8
set fileencoding=utf-8
set fileencodings=ucs-bom,utf8,prc
set guifont=Monaco:h11
set guifontwide=NSimsun:h12

"colorscheme  xoria256-pluk 


